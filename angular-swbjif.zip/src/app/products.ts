export const products = [
  {
    name: 'Iphone x',
    price: 799,
    description: 'El Apple iPhone X es el móvil de gama top de Apple de 2017 y llega al mercado con una pantalla OLED panorámica con notch y un peso de 174 g'
  },
  {
    name: 'Ipad mini',
    price: 699,
    description: 'El Apple iPad Mini tiene un tamaño de pantalla de 7,9" , con una resolución de 1024 x 768. La pantalla es de tipo IPS. Tiene una densidad de píxeles de 162 ppp'
  },
  {
    name: 'Iphone basico',
    price: 299,
    description: 'El Apple iPhone 6 sube la apuesta de Apple con una pantalla de mayor tamaño de 4.7 pulgadas protegida por un cristal ultra resistente, nuevo procesador A8, 16GB, 64GB o 128GB de almacenamiento interno,'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/